import { useInView } from "react-intersection-observer";
import { useState, useEffect } from "react";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
const testimonials = [{
  name: "Michael Chen",
  role: "Operations Director",
  company: "GlobalTrade Inc",
  image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
  rating: 5,
  text: "The workflow automation Aditya implemented saved us 40 hours per week in manual data entry. His attention to detail and understanding of our business needs was exceptional. Highly recommended!",
  project: "B2B Business Automation"
}, {
  name: "Emily Rodriguez",
  role: "Marketing Manager",
  company: "GrowthHub Agency",
  image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
  rating: 5,
  text: "Our lead generation increased by 300% after implementing Aditya's AI agent system. The quality of leads improved dramatically, and our conversion rates are through the roof. Amazing work!",
  project: "Lead Generation AI Agent"
}, {
  name: "David Park",
  role: "Founder",
  company: "InnovateLab",
  image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
  rating: 5,
  text: "Working with Aditya was a game-changer for our startup. His AI automation solutions helped us scale operations without hiring additional staff. Professional, reliable, and incredibly skilled.",
  project: "Complete Business Automation"
}];
const Testimonials = () => {
  const {
    ref,
    inView
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-advance testimonials
  useEffect(() => {
    if (!isAutoPlaying) return;
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [isAutoPlaying]);
  const nextTestimonial = () => {
    setCurrentIndex(prev => (prev + 1) % testimonials.length);
    setIsAutoPlaying(false);
  };
  const prevTestimonial = () => {
    setCurrentIndex(prev => (prev - 1 + testimonials.length) % testimonials.length);
    setIsAutoPlaying(false);
  };
  const goToTestimonial = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
  };
  return <section id="testimonials" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <div ref={ref} className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass-card inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6">
            <div className="w-2 h-2 bg-primary rounded-full" />
            <span className="text-sm font-medium text-foreground/80">Client satisfaction</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            What Clients 
            <span className="gradient-text"> Say About Us</span>
          </h2>

          <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
            Real feedback from businesses that have transformed their operations 
            with AI automation solutions.
          </p>
        </div>

        {/* Testimonial Carousel */}
        <div className={`relative transition-all duration-1000 delay-300 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          
          {/* Main Testimonial Card */}
          <div className="glass-card p-8 md:p-12 rounded-3xl relative overflow-hidden">
            
            {/* Quote Icon */}
            <div className="absolute top-8 right-8 opacity-10">
              <Quote className="w-24 h-24 text-primary" />
            </div>

            {/* Current Testimonial */}
            <div className="relative z-10">
              
              {/* Stars Rating */}
              <div className="flex items-center gap-1 mb-6">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => <Star key={i} className="w-5 h-5 fill-primary text-primary" />)}
              </div>

              {/* Testimonial Text */}
              <blockquote className="text-xl md:text-2xl leading-relaxed text-foreground/90 mb-8">
                {testimonials[currentIndex].text}
              </blockquote>

              {/* Client Info */}
              <div>
                <div className="font-bold text-lg text-foreground">
                  {testimonials[currentIndex].name}
                </div>
                <div className="text-foreground/60">
                  {testimonials[currentIndex].role}
                </div>
                <div className="text-sm text-foreground/50">
                  {testimonials[currentIndex].company}
                </div>
              </div>

              {/* Project Tag */}
              <div className="mt-6">
                <span className="glass-card px-4 py-2 text-sm font-medium text-primary rounded-full">
                  {testimonials[currentIndex].project}
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between mt-8">
            
            {/* Previous/Next Buttons */}
            <div className="flex gap-3">
              <Button variant="glass" size="icon" onClick={prevTestimonial} className="rounded-full">
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button variant="glass" size="icon" onClick={nextTestimonial} className="rounded-full">
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>

            {/* Dot Indicators */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => <button key={index} onClick={() => goToTestimonial(index)} className={`w-3 h-3 rounded-full transition-all duration-300 ${index === currentIndex ? 'bg-primary scale-125' : 'bg-foreground/20 hover:bg-foreground/40'}`} />)}
            </div>

            {/* Auto-play Indicator */}
            
          </div>
        </div>

      </div>
    </section>;
};
export default Testimonials;