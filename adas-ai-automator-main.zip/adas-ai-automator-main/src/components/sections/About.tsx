import { useInView } from "react-intersection-observer";
import { Brain, Zap, Target, Lightbulb } from "lucide-react";
const skills = [{
  name: "AI Agents Development",
  percentage: 95,
  icon: Brain
}, {
  name: "n8n Automation",
  percentage: 90,
  icon: Zap
}, {
  name: "Chatbot Development",
  percentage: 88,
  icon: Target
}, {
  name: "Workflow Optimization",
  percentage: 92,
  icon: Lightbulb
}];
const About = () => {
  const {
    ref,
    inView
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  return <section id="about" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Full Width Text Content */}
        <div ref={ref} className={`transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass-card inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6">
            <div className="w-2 h-2 bg-primary rounded-full" />
            <span className="text-sm font-medium text-foreground/80">About Me</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Transforming Business with 
            <span className="gradient-text"> AI Agent</span>
          </h2>

          <div className="space-y-6 text-foreground/70 text-lg leading-relaxed">
            <p>With over 1 years of experience in AI automation & Agents. I specialize in creating intelligent solutions that streamline operations and boost productivity. My journey began with a passion for solving complex business challenges through innovative technology.</p>
            
            <p>I've helped dozens of businesses automate their workflows, reduce manual tasks by up to 80%, and scale their operations efficiently. </p>

            <p>My expertise spans platforms including  vapi, n8n, make , Retell Ai , GoHighLevel and Other Automation Tool. I focus on creating solutions that are powerful, intuitive, and easy to maintain </p>
          </div>

          {/* Certifications Button */}
          <div className="mt-8">
            <a href="https://drive.google.com/file/d/1rVs9jlNwrt1ci1E2_bxsl57iLphO_lc4/view?usp=sharing" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 hover:from-purple-600 hover:via-pink-600 hover:to-blue-600 text-white font-semibold text-lg transition-all duration-300 hover:scale-105 hover:shadow-xl shadow-lg backdrop-blur-sm border border-white/20">
              <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
              See My All Certifications
            </a>
          </div>
        </div>

        {/* Tools & Technologies */}
        <div className={`mt-16 transition-all duration-1000 delay-300 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="flex justify-center items-center">
            <div className="flex items-center justify-center gap-8 flex-wrap max-w-6xl">
              
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default About;