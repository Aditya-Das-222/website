import { Button } from "@/components/ui/button";
import { useInView } from "react-intersection-observer";
import { ExternalLink, Github, ArrowRight } from "lucide-react";
const projects = [{
  title: "E-commerce Order Automation",
  client: "Tech Startup",
  description: "Automated order processing system that reduced manual work by 85% and improved customer satisfaction.",
  tools: ["n8n", "Shopify API", "Slack", "Google Sheets"],
  results: "85% reduction in processing time, 95% accuracy rate",
  image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
  category: "Workflow Automation"
}, {
  title: "AI Customer Support Chatbot",
  client: "SaaS Company",
  description: "24/7 AI chatbot handling customer queries with 90% resolution rate without human intervention.",
  tools: ["OpenAI GPT", "WhatsApp API", "Zendesk", "Python"],
  results: "90% query resolution, 60% support cost reduction",
  image: "/lovable-uploads/97b6a708-efd7-4366-a398-880c20df168b.png",
  category: "Chatbot Development"
}, {
  title: "Lead Generation AI Agent",
  client: "Marketing Agency",
  description: "Intelligent lead scoring and outreach system that increased qualified leads by 300%.",
  tools: ["OpenAI", "LinkedIn API", "HubSpot", "n8n"],
  results: "300% increase in qualified leads, 45% conversion rate",
  image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
  category: "Lead Generation"
}, {
  title: "Real-time Analytics Dashboard",
  client: "E-commerce Platform",
  description: "Custom dashboard providing real-time insights into sales, inventory, and customer behavior.",
  tools: ["Power BI", "Python", "SQL", "REST APIs"],
  results: "Real-time insights, 40% faster decision making",
  image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
  category: "Analytics & Dashboards"
}, {
  title: "HR Recruitment Automation",
  client: "Corporate Enterprise",
  description: "Automated recruitment pipeline from job posting to candidate screening and interview scheduling.",
  tools: ["Make.com", "LinkedIn", "Calendly", "ATS Integration"],
  results: "70% faster hiring process, 50% cost reduction",
  image: "/lovable-uploads/a031dace-3ef8-477a-97c6-f6c6c6680841.png",
  category: "Workflow Automation"
}, {
  title: "Voice AI Assistant",
  client: "Restaurant Chain",
  description: "Voice-enabled ordering system that handles phone orders and reservations automatically.",
  tools: ["OpenAI Whisper", "ElevenLabs", "Twilio", "POS Integration"],
  results: "24/7 availability, 80% order accuracy improvement",
  image: "/lovable-uploads/faab0902-2ba4-4c5c-9ecf-643d471a6150.png",
  category: "Voice AI"
}];
const Projects = () => {
  const {
    ref,
    inView
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  return <section id="projects" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div ref={ref} className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass-card inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6">
            <div className="w-2 h-2 bg-primary rounded-full" />
            <span className="text-sm font-medium text-foreground/80">Portfolio</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Featured 
            <span className="gradient-text"> Projects</span>
          </h2>

          <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
            Explore some of my successful AI automation projects that have transformed 
            businesses and delivered measurable results.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => <div key={project.title} className={`glass-card-hover rounded-3xl overflow-hidden group transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{
          transitionDelay: `${200 + index * 150}ms`
        }}>
              {/* Project Image */}
              <div className="relative overflow-hidden h-48">
                <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Category Badge */}
                <div className="absolute top-4 left-4">
                  <span className="glass-card px-3 py-1 text-xs font-medium text-foreground/90 rounded-full">
                    {project.category}
                  </span>
                </div>

                {/* Hover Actions */}
                <div className="absolute inset-0 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  
                  
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                </div>

                <p className="text-sm text-foreground/60 mb-3">{project.client}</p>
                
                <p className="text-foreground/70 mb-4 line-clamp-3">
                  {project.description}
                </p>

                {/* Tools Used */}
                

                {/* Results */}
                <div className="glass-card p-3 rounded-xl mb-4">
                  <div className="text-xs font-medium text-foreground/60 mb-1">Results</div>
                  <div className="text-sm text-foreground/80">{project.results}</div>
                </div>

                {/* CTA */}
                
              </div>
            </div>)}
        </div>

        {/* Load More CTA */}
        <div className={`text-center mt-12 transition-all duration-1000 delay-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <Button variant="hero" size="lg" onClick={() => window.open('https://wa.me/8801317003255', '_blank')}>
            See More Projects
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </section>;
};
export default Projects;