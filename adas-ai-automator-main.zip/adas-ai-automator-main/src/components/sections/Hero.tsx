import { Button } from "@/components/ui/button";
import { ArrowDown, Download, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";
const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    setIsVisible(true);
  }, []);
  return <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-4 pt-24 md:pt-32">
      {/* Enhanced Animated Background Elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {/* Primary floating orbs */}
        <div className="absolute top-20 left-20 w-96 h-96 rounded-full opacity-60 blur-3xl float-animation" style={{
        background: 'radial-gradient(circle, rgba(147, 51, 234, 0.3) 0%, rgba(236, 72, 153, 0.2) 50%, transparent 100%)',
        animationDelay: '0s'
      }} />
        
        <div className="absolute top-40 right-20 w-[500px] h-[500px] rounded-full opacity-50 blur-3xl float-animation" style={{
        background: 'radial-gradient(circle, rgba(59, 130, 246, 0.3) 0%, rgba(147, 51, 234, 0.2) 50%, transparent 100%)',
        animationDelay: '3s'
      }} />
        
        <div className="absolute bottom-20 left-1/3 w-80 h-80 rounded-full opacity-70 blur-3xl float-animation" style={{
        background: 'radial-gradient(circle, rgba(236, 72, 153, 0.3) 0%, rgba(251, 146, 60, 0.2) 50%, transparent 100%)',
        animationDelay: '1.5s'
      }} />

        {/* Additional ambient orbs */}
        <div className="absolute top-1/2 left-10 w-60 h-60 rounded-full opacity-40 blur-2xl animate-pulse" style={{
        background: 'radial-gradient(circle, rgba(168, 85, 247, 0.2) 0%, transparent 70%)',
        animationDelay: '2s'
      }} />
        
        <div className="absolute bottom-1/3 right-10 w-72 h-72 rounded-full opacity-30 blur-2xl animate-pulse" style={{
        background: 'radial-gradient(circle, rgba(34, 197, 94, 0.2) 0%, transparent 70%)',
        animationDelay: '4s'
      }} />

        {/* Gradient mesh overlay */}
        <div className="absolute inset-0 opacity-20" style={{
        background: `
                 radial-gradient(circle at 20% 80%, rgba(147, 51, 234, 0.3) 0%, transparent 50%),
                 radial-gradient(circle at 80% 20%, rgba(236, 72, 153, 0.3) 0%, transparent 50%),
                 radial-gradient(circle at 40% 40%, rgba(59, 130, 246, 0.2) 0%, transparent 50%)
               `
      }} />
      </div>

      {/* Main Content */}
      <div className={`relative z-10 text-center max-w-6xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        

        {/* Main Headline with Profile Image */}
        <div className="flex flex-col lg:flex-row items-center justify-center gap-6 lg:gap-8 mb-6">
          <div className="lg:flex-1 order-2 lg:order-1">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
              <span className="block">Hi, I'm</span>
              <span className="gradient-text">Aditya Das</span>
              <span className="block text-xl md:text-2xl mt-3 text-foreground/90 mx-0 font-bold my-px lg:text-lg">AI-Driven Business Operations Specialist</span>
            </h1>
          </div>
          <div className="lg:flex-1 flex justify-center lg:justify-start order-1 lg:order-2 mt-4 lg:mt-8">
            <img src="/lovable-uploads/9b7ae170-1175-4ffc-806d-fd96159fe1a2.png" alt="Aditya Das" className="w-32 h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 rounded-full object-cover ring-4 ring-primary/20 shadow-2xl" />
          </div>
        </div>
          
        {/* Agency Branding */}
        <div className="flex items-center justify-center gap-3 mt-4">
          <img src="/lovable-uploads/14bcde09-cf75-409a-bcbf-e346efc47a4f.png" alt="Trigger X" className="w-10 h-10 md:w-12 md:h-12 object-contain opacity-90" />
          <div className="flex flex-col items-start text-left">
            <span className="text-base md:text-lg text-slate-100">Founder &amp; CEO at </span>
            <span className="text-xl md:text-2xl lg:text-3xl gradient-text-secondary font-bold">
              Trigger X
            </span>
          </div>
        </div>

        {/* Subheadline */}
        <p className="text-lg md:text-xl text-foreground/70 mb-10 max-w-3xl mx-auto leading-relaxed">
          We help businesses save time, cut costs, and scale with 
          <span className="gradient-text-secondary font-semibold"> AI-powered automation</span>
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button variant="hero" size="lg" className="group" onClick={() => window.open('https://wa.me/8801317003255', '_blank')}>
            <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
            Let's Work Together
          </Button>
          
          <Button variant="glass" size="lg" onClick={() => document.getElementById('about')?.scrollIntoView({
          behavior: 'smooth'
        })}>
            <Download className="w-5 h-5" />
            View My Work
          </Button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-6 h-6 text-foreground/60" />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-16">
          <div className="glass-card-hover p-4 text-center rounded-2xl">
            <div className="text-2xl font-bold gradient-text mb-2">100+</div>
            <div className="text-foreground/60 text-sm">Projects Completed</div>
          </div>
          
          <div className="glass-card-hover p-4 text-center rounded-2xl">
            <div className="text-2xl font-bold gradient-text mb-2">95%</div>
            <div className="text-foreground/60 text-sm">Client Satisfaction</div>
          </div>
          
          <div className="glass-card-hover p-4 text-center rounded-2xl">
            <div className="text-2xl font-bold gradient-text mb-2">24/7</div>
            <div className="text-foreground/60 text-sm">Support Available</div>
          </div>
        </div>
      </div>
    </section>;
};
export default Hero;