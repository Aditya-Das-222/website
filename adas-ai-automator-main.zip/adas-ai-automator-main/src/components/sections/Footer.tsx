import { Heart, Linkedin, Users, Mail, MessageCircle, Youtube } from "lucide-react";
const Footer = () => {
  return <footer className="py-12 px-4 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        
        {/* Main Footer Content */}
        

        {/* Bottom Section */}
        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            
            {/* Copyright */}
            <div className="flex items-center gap-2 text-foreground/60 text-sm">
              <span className="text-slate-50">© 2025 Trigger X . All Rights Reserved</span>
            </div>

            {/* Additional Info */}
            <div className="flex items-center gap-6 text-sm text-foreground/60">
              
              
            </div>
          </div>
        </div>

        {/* Floating WhatsApp Chatbot */}
        <div className="fixed bottom-6 right-6 z-50">
          <a href="https://wa.me/8801317003255" target="_blank" rel="noopener noreferrer" className="group relative">
            {/* Chat bubble with pulse animation */}
            <div className="glass-card-hover p-4 rounded-full bg-green-500/20 border-2 border-green-400/40 hover:bg-green-500/30 transition-all duration-300 shadow-lg shadow-green-500/20 hover:shadow-green-500/40 hover:shadow-xl">
              <MessageCircle className="w-7 h-7 text-green-400 group-hover:scale-110 transition-transform" />
              
              {/* Pulse rings */}
              <div className="absolute inset-0 rounded-full bg-green-400/30 animate-ping" />
              <div className="absolute inset-0 rounded-full bg-green-400/20 animate-pulse" />
            </div>
            
            {/* Chat label */}
            <div className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="glass-card px-3 py-2 rounded-lg whitespace-nowrap bg-green-500/10 border-green-400/30">
                <span className="text-sm text-green-400 font-medium">Chat with me!</span>
              </div>
            </div>
          </a>
        </div>
      </div>
    </footer>;
};
export default Footer;