import { Button } from "@/components/ui/button";
import { useInView } from "react-intersection-observer";
import { MessageCircle, Mail, Linkedin, Users, Send, Instagram, Facebook, Twitter, GraduationCap } from "lucide-react";
import fiverLogo from "@/assets/fiverr-logo.png";
const marketplaceProfiles = [{
  icon: Facebook,
  title: "Facebook",
  description: "Connect on Facebook",
  value: "Follow my updates",
  action: () => window.open('https://www.facebook.com/share/1EyguAzC8Z/', '_blank'),
  color: "from-blue-600 to-blue-700"
}, {
  icon: Instagram,
  title: "Instagram",
  description: "Follow my journey",
  value: "Follow on Instagram",
  action: () => window.open('https://www.instagram.com/aditya_das_222?igsh=MXd3OGF1am5ibnRjZA==', '_blank'),
  color: "from-pink-500 to-purple-500"
}];
const socialMedia = [{
  icon: Linkedin,
  title: "LinkedIn",
  description: "Professional network",
  value: "Connect with me",
  action: () => window.open('https://www.linkedin.com/in/-aditya-das-222-/', '_blank'),
  color: "from-blue-600 to-blue-700"
}, {
  icon: Users,
  title: "YouTube Channel",
  description: "Subscribe on YouTube",
  value: "Subscribe on YouTube",
  action: () => window.open('https://www.youtube.com/channel/UCUYswYm83k_1PYdN-1NAk4Q', '_blank'),
  color: "from-red-500 to-red-600"
}, {
  icon: Twitter,
  title: "X (Twitter)",
  description: "Follow on X",
  value: "Follow on X",
  action: () => window.open('https://x.com/Aditya_das_222?t=_t0mfpywJOZJeQUuZVsQPA&s=09', '_blank'),
  color: "from-gray-800 to-black"
}, {
  icon: GraduationCap,
  title: "Skool",
  description: "Follow my skool",
  value: "Join on Skool",
  action: () => window.open('https://skool.com/@aditya-das-5910', '_blank'),
  color: "from-purple-600 to-purple-700"
}];
const contactInfo = [{
  icon: MessageCircle,
  title: "WhatsApp",
  description: "Quick response guaranteed",
  value: "+880 1317 003255",
  action: () => window.open('https://wa.me/8801317003255', '_blank'),
  color: "from-green-500 to-green-600"
}, {
  icon: Mail,
  title: "Email",
  description: "Professional inquiries",
  value: "x.aditya.das.222@gmail.com",
  action: () => window.open('https://mail.google.com/mail/?view=cm&fs=1&to=x.aditya.das.222@gmail.com', '_blank'),
  color: "from-blue-500 to-blue-600"
}];
const Contact = () => {
  const {
    ref,
    inView
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  return <section id="contact" className="px-4 py-[8px]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div ref={ref} className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass-card inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-sm font-medium text-foreground/80">Connect With Me</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let's Build Something 
            <span className="gradient-text"> Amazing Together</span>
          </h2>

          
        </div>

        {/* Equal-sized Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          
          {/* Marketplace Profiles */}
          {marketplaceProfiles.map((profile, index) => {
          const Icon = profile.icon;
          return <div key={profile.title} className={`glass-card-hover p-6 rounded-3xl cursor-pointer group transition-all duration-700 h-full ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{
            transitionDelay: `${300 + index * 150}ms`
          }} onClick={profile.action}>
                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${profile.color} p-3 mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
                  {profile.title}
                </h3>
                
                <p className="text-foreground/60 text-sm mb-3">
                  {profile.description}
                </p>
                
                <p className="text-foreground/80 font-medium">
                  {profile.value}
                </p>

                <div className="mt-4 flex items-center gap-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  <Send className="w-4 h-4" />
                  <span className="text-sm">View profile</span>
                </div>
              </div>;
        })}

          {/* Social Media */}
          {socialMedia.map((social, index) => {
          const Icon = social.icon;
          return <div key={social.title} className={`glass-card-hover p-6 rounded-3xl cursor-pointer group transition-all duration-700 h-full ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{
            transitionDelay: `${500 + index * 150}ms`
          }} onClick={social.action}>
                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${social.color} p-3 mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
                  {social.title}
                </h3>
                
                <p className="text-foreground/60 text-sm mb-3">
                  {social.description}
                </p>
                
                <p className="text-foreground/80 font-medium">
                  {social.value}
                </p>

                <div className="mt-4 flex items-center gap-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  <Send className="w-4 h-4" />
                  <span className="text-sm">Follow now</span>
                </div>
              </div>;
        })}
        </div>

        {/* Main CTA Section */}
        <div className={`text-center transition-all duration-1000 delay-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass-card p-8 md:p-12 rounded-3xl max-w-4xl mx-auto relative overflow-hidden">
            
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-primary/20 to-accent/20" />
            </div>

            <div className="relative z-10">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">Unlock Your Business <span className="gradient-text">Potential with AI</span></h3>
              
              

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="hero" size="xl" onClick={() => window.open('https://wa.me/8801317003255', '_blank')} className="group">
                  <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  Start Project Discussion
                </Button>
                
                <Button variant="glass" size="xl" onClick={() => window.open('https://mail.google.com/mail/?view=cm&fs=1&to=x.aditya.das.222@gmail.com', '_blank')}>
                  <Mail className="w-5 h-5" />
                  Send Email
                </Button>
              </div>

              <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-foreground/60">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span>Free consultation</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full" />
                  <span>Quick response</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-400 rounded-full" />
                  <span>Custom solutions</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default Contact;