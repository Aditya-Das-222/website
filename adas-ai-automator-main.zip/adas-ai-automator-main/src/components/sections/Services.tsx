import { useInView } from "react-intersection-observer";
import { Store, Building, Home, Scissors, Wrench, Monitor, Scale, Hammer, Calendar, GraduationCap, Heart, Truck, Package, Cloud, ShoppingCart, Building2 } from "lucide-react";
const industries = [{
  icon: Store,
  name: "E-commerce Stores"
}, {
  icon: Building,
  name: "Agencies"
}, {
  icon: Home,
  name: "Real Estate Businesses"
}, {
  icon: Scissors,
  name: "Beauty Salon"
}, {
  icon: Wrench,
  name: "Plumbing Services"
}, {
  icon: Monitor,
  name: "IT Service Providers"
}, {
  icon: Scale,
  name: "Legal Services"
}, {
  icon: Hammer,
  name: "Construction Companies"
}, {
  icon: Calendar,
  name: "Event Management Firms"
}, {
  icon: GraduationCap,
  name: "Education & Coaching Centers"
}, {
  icon: Heart,
  name: "Healthcare Providers"
}, {
  icon: Truck,
  name: "Logistics & Transportation"
}, {
  icon: Package,
  name: "Import-Export Businesses"
}, {
  icon: Cloud,
  name: "SaaS Providers"
}, {
  icon: ShoppingCart,
  name: "Retailers"
}, {
  icon: Building2,
  name: "Other B2B Businesses"
}];
const aiServices = ["Custom solution based on your problem", "Automated Customer Support (Website, Instagram, Messenger, WhatsApp, LinkedIn)", "Lead Generation & Cold DM Outreach", "Voice Assistant Integration (Inbound, Outbound)", "Sales and Marketing Automation", "Social Media Automation (Facebook, Instagram, LinkedIn, X, YouTube)", "Data Entry & CRM Updates", "Dashboard & Analytics Setup", "AI Employee", "AI Receptionist"];
const Services = () => {
  const {
    ref,
    inView
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  const {
    ref: ref2,
    inView: inView2
  } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });
  return <section id="services" className="px-4 py-[8px]">
      <div className="max-w-7xl mx-auto">
        
        {/* Industries We Serve Section */}
        <div ref={ref} className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Industries <span className="gradient-text">We Serve</span>
          </h2>
        </div>

        {/* Industries Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-20">
          {industries.map((industry, index) => {
          const Icon = industry.icon;
          return <div key={index} className={`glass-card p-6 rounded-2xl text-center transition-all duration-700 hover:scale-105 hover:shadow-xl group cursor-pointer ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{
            transitionDelay: `${index * 50}ms`
          }}>
                <div className="bg-gradient-to-r from-primary to-primary-glow p-3 rounded-xl inline-flex mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-foreground/90">{industry.name}</h3>
              </div>;
        })}
        </div>

        {/* AI Agents Section */}
        <div ref={ref2} className={`text-center mb-16 transition-all duration-1000 ${inView2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            How AI Agents Can <span className="gradient-text">Transform Your Business</span>
          </h2>
        </div>

        {/* Services List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {aiServices.map((service, index) => <div key={index} className={`glass-card p-6 rounded-2xl flex items-start gap-4 transition-all duration-700 hover:scale-105 hover:shadow-xl ${inView2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{
          transitionDelay: `${index * 50}ms`
        }}>
              <div className="bg-gradient-to-r from-primary to-primary-glow w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white text-sm font-bold">{index + 1}</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground leading-relaxed">{service}</h3>
              </div>
            </div>)}
        </div>

      </div>
    </section>;
};
export default Services;